import React from 'react'
import ReactDOM from 'react-dom/client'
import './index.css'
import WorkoutApp from './WorkoutApp'

// Shim for window.storage — uses localStorage when running outside Claude artifacts
if (!window.storage) {
  window.storage = {
    get: async (key) => {
      const value = localStorage.getItem(key)
      return value !== null ? { key, value } : null
    },
    set: async (key, value) => {
      localStorage.setItem(key, value)
      return { key, value }
    },
    delete: async (key) => {
      localStorage.removeItem(key)
      return { key, deleted: true }
    },
    list: async (prefix = '') => {
      const keys = Object.keys(localStorage).filter(k => k.startsWith(prefix))
      return { keys, prefix }
    },
  }
}

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <WorkoutApp />
  </React.StrictMode>
)
