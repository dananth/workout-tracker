import React, { useState, useEffect, useCallback } from 'react';
import { Dumbbell, Check, ChevronDown, ChevronUp, Flame, TrendingUp, X, Settings, RotateCcw, ArrowUp } from 'lucide-react';

const PHASES = [
  {
    id: 'w1-2', label: 'Weeks 1–2', title: 'Foundation',
    note: 'Light weights (50–60% guess-max). Focus on form.',
    sessionsPerWeekRange: [2, 3],
    sessions: [
      { name: 'Full Body A', exercises: [
        { name: 'Squats (bodyweight or light bar)', target: '3 × 10', hasWeight: true },
        { name: 'Push-ups (knee variation OK)', target: '3 × 8–10', hasWeight: false },
        { name: 'Dumbbell rows', target: '3 × 10', hasWeight: true },
        { name: 'Plank', target: '3 × 20–30s', hasWeight: false },
        { name: 'Incline walk or cycling', target: '15–20 min', hasWeight: false },
      ]},
      { name: 'Full Body B', exercises: [
        { name: 'Lunges (each leg)', target: '2 × 10', hasWeight: true },
        { name: 'Push-ups (knee variation OK)', target: '3 × 8–10', hasWeight: false },
        { name: 'Dumbbell rows', target: '3 × 10', hasWeight: true },
        { name: 'Squats (bodyweight or light bar)', target: '3 × 10', hasWeight: true },
        { name: 'Plank', target: '3 × 20–30s', hasWeight: false },
      ]},
    ],
  },
  {
    id: 'w3-4', label: 'Weeks 3–4', title: 'Build',
    note: 'Slightly heavier loads. Add cardio.',
    sessionsPerWeekRange: [3, 4],
    sessions: [
      { name: 'Full Body A', exercises: [
        { name: 'Squats', target: '3 × 12, ↑ weight slightly', hasWeight: true },
        { name: 'Bench press / DB chest press', target: '3 × 10', hasWeight: true },
        { name: 'Lat pulldown / assisted pull-ups', target: '3 × 8–10', hasWeight: true },
        { name: 'Plank / core work', target: '3 sets', hasWeight: false },
        { name: 'Cardio', target: '20–25 min', hasWeight: false },
      ]},
      { name: 'Full Body B', exercises: [
        { name: 'Deadlifts (light, form focus)', target: '3 × 8', hasWeight: true },
        { name: 'Overhead press', target: '3 × 10', hasWeight: true },
        { name: 'Lat pulldown / assisted pull-ups', target: '3 × 8–10', hasWeight: true },
        { name: 'Squats', target: '3 × 12', hasWeight: true },
        { name: 'Plank / core work', target: '3 sets', hasWeight: false },
      ]},
      { name: 'Full Body C + Cardio', exercises: [
        { name: 'Bench press / DB chest press', target: '3 × 10', hasWeight: true },
        { name: 'Deadlifts (light, form focus)', target: '3 × 8', hasWeight: true },
        { name: 'Overhead press', target: '3 × 10', hasWeight: true },
        { name: 'Cardio', target: '25 min', hasWeight: false },
      ]},
    ],
  },
  {
    id: 'w5-6', label: 'Weeks 5–6', title: 'Progress',
    note: 'Push / Pull / Legs split. ↑ weight 5–10% where reps feel easy.',
    sessionsPerWeekRange: [3, 5],
    sessions: [
      { name: 'Push Day', exercises: [
        { name: 'Bench press / DB chest press', target: '4 × 8–10', hasWeight: true },
        { name: 'Overhead press', target: '3 × 10', hasWeight: true },
        { name: 'Incline DB press or push-ups', target: '3 × 10', hasWeight: true },
        { name: 'Tricep extensions', target: '3 × 12', hasWeight: true },
        { name: 'Cardio (intervals)', target: '10–15 min', hasWeight: false },
      ]},
      { name: 'Pull Day', exercises: [
        { name: 'Deadlifts', target: '4 × 6–8', hasWeight: true },
        { name: 'Lat pulldown / pull-ups', target: '3 × 8–10', hasWeight: true },
        { name: 'Dumbbell rows', target: '3 × 10', hasWeight: true },
        { name: 'Bicep curls', target: '3 × 12', hasWeight: true },
        { name: 'Cardio (steady-state)', target: '15 min', hasWeight: false },
      ]},
      { name: 'Leg Day', exercises: [
        { name: 'Squats', target: '4 × 10', hasWeight: true },
        { name: 'Lunges (each leg)', target: '3 × 10', hasWeight: true },
        { name: 'Leg press or step-ups', target: '3 × 12', hasWeight: true },
        { name: 'Calf raises', target: '3 × 15', hasWeight: true },
        { name: 'Plank / core work', target: '3 sets', hasWeight: false },
      ]},
    ],
  },
];

const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

const todayKey = () => new Date().toISOString().slice(0, 10);
const addDays = (key, n) => { const d = new Date(key + 'T00:00:00'); d.setDate(d.getDate() + n); return d.toISOString().slice(0, 10); };
const dateLabel = (d) => new Date(d + 'T00:00:00').toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' });
const kgToLb = (kg) => +(kg * 2.20462).toFixed(1);
const lbToKg = (lb) => +(lb / 2.20462).toFixed(1);
const fmt = (kg, unit) => unit === 'kg' ? `${kg} kg` : `${kgToLb(kg)} lb`;

function usePersistedState(key, fallback) {
  const [value, setValue] = useState(fallback);
  const [loaded, setLoaded] = useState(false);
  useEffect(() => {
    (async () => {
      try { const res = await window.storage.get(key, false); setValue(res ? JSON.parse(res.value) : fallback); }
      catch { setValue(fallback); }
      setLoaded(true);
    })();
  }, []);
  const save = useCallback(async (next) => {
    setValue(next);
    try { await window.storage.set(key, JSON.stringify(next), false); } catch (e) { console.error(e); }
  }, [key]);
  return [value, save, loaded];
}

function buildSchedule(startDate, workoutDays, phaseIndex, log) {
  const today = todayKey();
  const daysPerWeek = workoutDays.length || 3;
  const daysSinceStart = Math.floor((new Date(today) - new Date(startDate)) / 86400000) + 21;
  const weeksNeeded = Math.ceil(daysSinceStart / 7) + 3;
  const sortedDays = [...workoutDays].sort((a, b) => a - b);
  const slotDates = [];

  // For each week, find the calendar date of each selected weekday
  const startMonday = new Date(startDate + 'T00:00:00');
  // Rewind to Sunday of the week containing startDate
  const startSunday = new Date(startMonday);
  startSunday.setDate(startMonday.getDate() - startMonday.getDay());

  for (let w = 0; w < weeksNeeded; w++) {
    for (const dow of sortedDays) {
      const d = new Date(startSunday);
      d.setDate(startSunday.getDate() + w * 7 + dow);
      const key = d.toISOString().slice(0, 10);
      if (key >= startDate) slotDates.push(key);
    }
  }

  const uniqueDates = [...new Set(slotDates)].sort();
  const totalSlots = uniqueDates.length;
  const sessions = PHASES[phaseIndex].sessions;
  const schedule = [];
  let pushOffset = 0;
  for (let i = 0; i < totalSlots; i++) {
    const shiftIdx = i + pushOffset;
    const effectiveDate = shiftIdx < totalSlots ? uniqueDates[shiftIdx] : addDays(uniqueDates[totalSlots - 1], (shiftIdx - totalSlots + 1) * Math.max(1, Math.floor(7 / daysPerWeek)));
    const sessionIndex = i % sessions.length;
    const isLogged = !!(log[effectiveDate]?.__sessionIndex === sessionIndex && Object.keys(log[effectiveDate] || {}).some(k => k.startsWith('ex::')));
    let status = effectiveDate < today ? (isLogged ? 'done' : 'missed') : effectiveDate === today ? (isLogged ? 'done' : 'today') : 'upcoming';
    schedule.push({ date: effectiveDate, sessionIndex, status });
    if (status === 'missed') pushOffset++;
  }
  return schedule;
}

// Find the last logged weight (in kg) for a given exercise name across all log dates
function getLastWeight(log, exName) {
  const dates = Object.keys(log).sort().reverse();
  for (const d of dates) {
    const w = log[d]?.[`wt::${exName}`];
    if (w !== undefined && w !== '') return Number(w);
  }
  return null;
}

// WeightInput: shows kg and lb fields that stay in sync. Stores value as kg internally.
function WeightInput({ exName, valueKg, onChange, unit }) {
  const [kgVal, setKgVal] = useState(valueKg !== null ? String(valueKg) : '');
  const [lbVal, setLbVal] = useState(valueKg !== null ? String(kgToLb(valueKg)) : '');

  useEffect(() => {
    if (valueKg === null || valueKg === undefined || valueKg === '') {
      setKgVal(''); setLbVal('');
    } else {
      setKgVal(String(valueKg));
      setLbVal(String(kgToLb(Number(valueKg))));
    }
  }, [valueKg]);

  const handleKg = (e) => {
    const v = e.target.value;
    setKgVal(v);
    const n = parseFloat(v);
    if (!isNaN(n) && n >= 0) { setLbVal(String(kgToLb(n))); onChange(n); }
    else if (v === '') { setLbVal(''); onChange(''); }
  };

  const handleLb = (e) => {
    const v = e.target.value;
    setLbVal(v);
    const n = parseFloat(v);
    if (!isNaN(n) && n >= 0) { const kg = lbToKg(n); setKgVal(String(kg)); onChange(kg); }
    else if (v === '') { setKgVal(''); onChange(''); }
  };

  const inputCls = "w-full bg-[#1A1D1E] border border-[#3C4044] rounded-lg px-2.5 py-1.5 text-sm text-[#F5F1EA] placeholder-[#4B5054] focus:outline-none focus:border-[#E8623A] transition-colors text-center";

  return (
    <div className="flex gap-2 mt-2" onClick={e => e.stopPropagation()}>
      <div className="flex-1">
        <div className="text-[10px] text-[#6B7280] text-center mb-1 uppercase tracking-wide">kg</div>
        <input
          type="number" min="0" step="0.5"
          value={kgVal}
          onChange={handleKg}
          placeholder="0"
          className={inputCls}
        />
      </div>
      <div className="flex items-center pt-4 text-[#4B5054] text-xs">=</div>
      <div className="flex-1">
        <div className="text-[10px] text-[#6B7280] text-center mb-1 uppercase tracking-wide">lb</div>
        <input
          type="number" min="0" step="1"
          value={lbVal}
          onChange={handleLb}
          placeholder="0"
          className={inputCls}
        />
      </div>
    </div>
  );
}

export default function WorkoutApp() {
  const [log, saveLog, logLoaded] = usePersistedState('workout-log-v3', {});
  const [settings, saveSettings, settingsLoaded] = usePersistedState('workout-settings-v4', {
    workoutDays: [1, 3, 5], phaseIndex: 0, startDate: todayKey(), unit: 'kg',
  });
  const [showSettings, setShowSettings] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [openExercises, setOpenExercises] = useState(true);

  const loaded = logLoaded && settingsLoaded;
  if (!loaded) return (
    <div className="min-h-screen flex items-center justify-center bg-[#1A1D1E] text-[#F5F1EA]">
      <div className="flex items-center gap-3 text-sm"><Dumbbell className="w-5 h-5 animate-pulse" />Loading…</div>
    </div>
  );

  const { workoutDays, phaseIndex, startDate, unit } = settings;
  const phase = PHASES[phaseIndex];
  const schedule = buildSchedule(startDate, workoutDays, phaseIndex, log);
  const today = todayKey();
  const todaySlot = schedule.find(s => s.date === today);
  const upcomingSlots = schedule.filter(s => s.date >= today).slice(0, 4);
  const missedSlots = schedule.filter(s => s.status === 'missed');
  const todaySession = todaySlot ? phase.sessions[todaySlot.sessionIndex] : null;
  const todayLog = log[today] || {};

  const loggedDates = Object.keys(log).filter(d => Object.keys(log[d] || {}).some(k => k.startsWith('ex::'))).sort();
  const totalSessions = loggedDates.length;
  let streak = 0;
  const pastSlots = schedule.filter(s => s.date <= today).reverse();
  for (const slot of pastSlots) {
    if (slot.status === 'done') streak++;
    else if (slot.date === today) continue;
    else break;
  }

  const updateSetting = (key, val) => saveSettings({ ...settings, [key]: val });
  const resetPlan = () => { saveSettings({ ...settings, phaseIndex: 0, startDate: today }); setShowSettings(false); };

  const toggleExercise = (exName) => {
    if (!todaySlot) return;
    const entry = { ...(log[today] || {}), __sessionIndex: todaySlot.sessionIndex };
    const key = `ex::${exName}`;
    if (entry[key]) delete entry[key]; else entry[key] = true;
    const hasAny = Object.keys(entry).some(k => k.startsWith('ex::'));
    const next = { ...log };
    if (hasAny) next[today] = entry; else delete next[today];
    saveLog(next);
  };

  const setWeight = (exName, kg) => {
    if (!todaySlot) return;
    const entry = { ...(log[today] || {}), __sessionIndex: todaySlot.sessionIndex };
    if (kg === '' || kg === null) delete entry[`wt::${exName}`];
    else entry[`wt::${exName}`] = kg;
    saveLog({ ...log, [today]: entry });
  };

  const isChecked = (exName) => !!todayLog[`ex::${exName}`];
  const getTodayWeight = (exName) => todayLog[`wt::${exName}`] ?? null;

  return (
    <div className="min-h-screen bg-[#1A1D1E] text-[#F5F1EA]" style={{ fontFamily: "'Inter', system-ui, sans-serif" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Oxanium:wght@600;700;800&family=Inter:wght@400;500;600;700&display=swap');
        .display { font-family: 'Oxanium', system-ui, sans-serif; }
        input[type=number]::-webkit-inner-spin-button,
        input[type=number]::-webkit-outer-spin-button { -webkit-appearance: none; margin: 0; }
        input[type=number] { -moz-appearance: textfield; }
      `}</style>

      {/* Header */}
      <header className="border-b border-[#2C3032] px-5 pt-8 pb-6">
        <div className="max-w-2xl mx-auto">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2 text-[#E8623A] text-xs font-semibold uppercase tracking-[0.2em]">
              <Dumbbell className="w-3.5 h-3.5" />Reboot Plan
            </div>
            <button onClick={() => setShowSettings(true)} className="text-[#9CA3AF] hover:text-[#F5F1EA] transition-colors p-1.5 -mr-1.5">
              <Settings className="w-4 h-4" />
            </button>
          </div>
          <h1 className="display text-3xl sm:text-4xl font-extrabold tracking-tight">Back to the Bar</h1>
          <p className="text-[#9CA3AF] text-sm mt-1.5">{workoutDays.sort((a,b)=>a-b).map(d=>DAYS[d]).join(' · ')} · {phase.label} — {phase.title}</p>

          <div className="flex gap-3 mt-5">
            <div className="flex-1 bg-[#22262A] rounded-lg px-4 py-3 border border-[#2C3032]">
              <div className="flex items-center gap-1.5 text-[#8B9D83] text-xs font-medium uppercase tracking-wide mb-1">
                <Flame className="w-3.5 h-3.5" />Streak
              </div>
              <div className="display text-2xl font-bold">{streak} <span className="text-sm text-[#9CA3AF] font-normal">session{streak === 1 ? '' : 's'}</span></div>
            </div>
            <div className="flex-1 bg-[#22262A] rounded-lg px-4 py-3 border border-[#2C3032]">
              <div className="flex items-center gap-1.5 text-[#E8623A] text-xs font-medium uppercase tracking-wide mb-1">
                <TrendingUp className="w-3.5 h-3.5" />Logged
              </div>
              <div className="display text-2xl font-bold">{totalSessions} <span className="text-sm text-[#9CA3AF] font-normal">total</span></div>
            </div>
          </div>

          {missedSlots.length > 0 && (
            <div className="mt-3 bg-[#2C2520] border border-[#E8623A]/30 rounded-lg px-4 py-2.5 text-xs text-[#E8B89A]">
              {missedSlots.length} session{missedSlots.length === 1 ? '' : 's'} missed — schedule shifted forward. Just pick up from today.
            </div>
          )}
        </div>
      </header>

      <main className="max-w-2xl mx-auto px-5 py-6">

        {/* Today card */}
        <div className="bg-[#22262A] rounded-xl border border-[#2C3032] overflow-hidden mb-4">
          <button onClick={() => setOpenExercises(!openExercises)} className="w-full flex items-center justify-between px-5 py-4 text-left">
            <div>
              <div className="flex items-baseline gap-2">
                <span className="text-[#E8623A] text-xs font-semibold uppercase tracking-[0.15em]">{todaySlot ? 'Today' : 'Rest Day'}</span>
                <span className="display text-lg font-bold">{todaySession ? todaySession.name : 'No session scheduled'}</span>
              </div>
              <p className="text-[#9CA3AF] text-xs mt-1">{dateLabel(today)} · {phase.note}</p>
            </div>
            {todaySession && (openExercises ? <ChevronUp className="w-4 h-4 text-[#9CA3AF] flex-shrink-0 ml-3" /> : <ChevronDown className="w-4 h-4 text-[#9CA3AF] flex-shrink-0 ml-3" />)}
          </button>

          {!todaySession && (
            <div className="border-t border-[#2C3032] px-5 py-4 text-sm text-[#9CA3AF]">
              Recovery day. Next session: <span className="text-[#F5F1EA] font-medium">{upcomingSlots[0] ? dateLabel(upcomingSlots[0].date) : 'soon'}</span>.
            </div>
          )}

          {todaySession && openExercises && (
            <div className="border-t border-[#2C3032] divide-y divide-[#2C3032]">
              {todaySession.exercises.map((ex) => {
                const checked = isChecked(ex.name);
                const todayWtKg = getTodayWeight(ex.name);
                const lastWtKg = getLastWeight(log, ex.name);
                const showSuggestion = ex.hasWeight && lastWtKg !== null && (todayWtKg === null || todayWtKg === '');

                return (
                  <div key={ex.name} className="px-5 py-3.5">
                    <div
                      className="flex items-center gap-3 cursor-pointer"
                      onClick={() => toggleExercise(ex.name)}
                    >
                      <span className={`flex-shrink-0 w-5 h-5 rounded border flex items-center justify-center transition-colors ${checked ? 'bg-[#8B9D83] border-[#8B9D83]' : 'border-[#4B5054]'}`}>
                        {checked && <Check className="w-3.5 h-3.5 text-[#1A1D1E]" strokeWidth={3} />}
                      </span>
                      <span className="flex-1 min-w-0">
                        <span className={`text-sm font-medium block ${checked ? 'text-[#9CA3AF] line-through' : 'text-[#F5F1EA]'}`}>{ex.name}</span>
                        <span className="text-xs text-[#6B7280]">{ex.target}</span>
                      </span>
                      {ex.hasWeight && todayWtKg !== null && todayWtKg !== '' && (
                        <span className="text-xs font-semibold text-[#8B9D83] flex-shrink-0">{fmt(todayWtKg, unit)}</span>
                      )}
                    </div>

                    {ex.hasWeight && (
                      <div className="ml-8">
                        {showSuggestion && (
                          <div className="flex items-center gap-1 mt-2 text-xs text-[#6B7280]">
                            <ArrowUp className="w-3 h-3 text-[#8B9D83]" />
                            Last session: <span className="text-[#8B9D83] font-medium ml-1">{fmt(lastWtKg, unit)}</span>
                          </div>
                        )}
                        <WeightInput
                          exName={ex.name}
                          valueKg={todayWtKg}
                          onChange={(kg) => setWeight(ex.name, kg)}
                          unit={unit}
                        />
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Upcoming */}
        <div className="bg-[#22262A] rounded-xl border border-[#2C3032] px-5 py-4 mb-4">
          <h3 className="display text-sm font-bold uppercase tracking-wide text-[#9CA3AF] mb-3">Upcoming</h3>
          <div className="space-y-2">
            {upcomingSlots.map((slot, i) => {
              const session = phase.sessions[slot.sessionIndex];
              const isToday = slot.date === today;
              return (
                <div key={i} className="flex items-center justify-between text-sm">
                  <span className={isToday ? 'text-[#E8623A] font-semibold' : 'text-[#F5F1EA]'}>{isToday ? 'Today' : dateLabel(slot.date)}</span>
                  <span className="text-[#9CA3AF] text-xs">{session.name}</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Phase */}
        <div className="bg-[#22262A] rounded-xl border border-[#2C3032] px-5 py-4 mb-6">
          <h3 className="display text-sm font-bold uppercase tracking-wide text-[#9CA3AF] mb-3">Plan Phase</h3>
          <div className="flex gap-2">
            {PHASES.map((p, i) => (
              <button key={p.id} onClick={() => updateSetting('phaseIndex', i)}
                className={`flex-1 rounded-lg px-3 py-2.5 text-left border transition-colors ${i === phaseIndex ? 'border-[#E8623A] bg-[#2C2520]' : 'border-[#2C3032] hover:border-[#4B5054]'}`}>
                <div className="text-xs text-[#9CA3AF]">{p.label}</div>
                <div className="display text-sm font-bold">{p.title}</div>
              </button>
            ))}
          </div>
          <p className="text-xs text-[#6B7280] mt-2">Switch phases manually when ready to progress.</p>
        </div>

        <button onClick={() => setShowHistory(true)} className="w-full text-center text-sm text-[#9CA3AF] hover:text-[#F5F1EA] transition-colors py-2">
          View logged history →
        </button>
      </main>

      {/* Settings modal */}
      {showSettings && (
        <div className="fixed inset-0 bg-black/60 flex items-end sm:items-center justify-center z-50" onClick={() => setShowSettings(false)}>
          <div className="bg-[#22262A] border border-[#2C3032] rounded-t-2xl sm:rounded-2xl w-full max-w-md max-h-[80vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between px-5 py-4 border-b border-[#2C3032] sticky top-0 bg-[#22262A]">
              <h2 className="display text-lg font-bold">Settings</h2>
              <button onClick={() => setShowSettings(false)} className="text-[#9CA3AF] hover:text-[#F5F1EA]"><X className="w-5 h-5" /></button>
            </div>
            <div className="px-5 py-5 space-y-5">

              <div>
                <label className="text-sm font-semibold block mb-2">Weight unit</label>
                <div className="flex gap-2">
                  {['kg', 'lb'].map(u => (
                    <button key={u} onClick={() => updateSetting('unit', u)}
                      className={`flex-1 rounded-lg py-2.5 text-sm font-semibold border transition-colors ${unit === u ? 'border-[#E8623A] bg-[#2C2520] text-[#E8623A]' : 'border-[#2C3032] text-[#9CA3AF] hover:border-[#4B5054]'}`}>
                      {u.toUpperCase()}
                    </button>
                  ))}
                </div>
                <p className="text-xs text-[#6B7280] mt-2">Sets your preferred unit for suggestions and history. Both kg and lb fields are always shown in the log.</p>
              </div>

              <div>
                <label className="text-sm font-semibold block mb-2">Workout days</label>
                <div className="grid grid-cols-7 gap-1.5">
                  {DAYS.map((day, i) => {
                    const active = workoutDays.includes(i);
                    return (
                      <button key={i}
                        onClick={() => {
                          const next = active
                            ? workoutDays.filter(d => d !== i)
                            : [...workoutDays, i];
                          if (next.length >= 1) updateSetting('workoutDays', next);
                        }}
                        className={`rounded-lg py-2 text-xs font-semibold border transition-colors ${active ? 'border-[#E8623A] bg-[#2C2520] text-[#E8623A]' : 'border-[#2C3032] text-[#9CA3AF] hover:border-[#4B5054]'}`}>
                        {day}
                      </button>
                    );
                  })}
                </div>
                <p className="text-xs text-[#6B7280] mt-2">Tap to toggle. Missed sessions shift forward automatically.</p>
              </div>

              <div className="pt-2 border-t border-[#2C3032]">
                <button onClick={resetPlan} className="w-full flex items-center justify-center gap-2 text-sm font-medium text-[#E8623A] border border-[#E8623A]/40 rounded-lg py-2.5 hover:bg-[#2C2520] transition-colors">
                  <RotateCcw className="w-3.5 h-3.5" />Restart plan from Week 1
                </button>
                <p className="text-xs text-[#6B7280] mt-2">Resets phase to Foundation. Logged history is kept.</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* History modal */}
      {showHistory && (
        <div className="fixed inset-0 bg-black/60 flex items-end sm:items-center justify-center z-50" onClick={() => setShowHistory(false)}>
          <div className="bg-[#22262A] border border-[#2C3032] rounded-t-2xl sm:rounded-2xl w-full max-w-md max-h-[75vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between px-5 py-4 border-b border-[#2C3032] sticky top-0 bg-[#22262A]">
              <h2 className="display text-lg font-bold">Logged sessions</h2>
              <button onClick={() => setShowHistory(false)} className="text-[#9CA3AF] hover:text-[#F5F1EA]"><X className="w-5 h-5" /></button>
            </div>
            <div className="divide-y divide-[#2C3032]">
              {loggedDates.length === 0 && (
                <p className="px-5 py-6 text-sm text-[#9CA3AF]">Nothing logged yet — check off an exercise to start.</p>
              )}
              {loggedDates.slice().reverse().map(d => {
                const entry = log[d] || {};
                const sessionIdx = entry.__sessionIndex;
                const sessionName = sessionIdx !== undefined ? phase.sessions[sessionIdx % phase.sessions.length]?.name : '';
                const weights = Object.entries(entry)
                  .filter(([k]) => k.startsWith('wt::') && entry[k] !== '' && entry[k] !== null)
                  .map(([k, v]) => ({ name: k.replace('wt::', ''), kg: Number(v) }));
                return (
                  <div key={d} className="px-5 py-3.5">
                    <div className="flex items-baseline justify-between mb-1">
                      <span className="text-sm font-semibold">{dateLabel(d)}</span>
                      {sessionName && <span className="text-xs text-[#9CA3AF]">{sessionName}</span>}
                    </div>
                    {weights.length > 0 ? (
                      <div className="space-y-1 mt-1">
                        {weights.map(w => (
                          <div key={w.name} className="flex items-center justify-between text-xs">
                            <span className="text-[#9CA3AF] truncate mr-3">{w.name}</span>
                            <span className="text-[#8B9D83] font-medium flex-shrink-0">{w.kg} kg · {kgToLb(w.kg)} lb</span>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-xs text-[#6B7280]">No weights logged this session</div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
